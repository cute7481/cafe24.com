package yoon.qget.model;

import java.sql.*;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

class QgetDAO {
	private DataSource ds;
	QgetDAO(){
		try{
			Context initContext = new InitialContext();
			Context envContext  = (Context)initContext.lookup("java:/comp/env");
			ds = (DataSource)envContext.lookup("jdbc/myoracle");
		}catch(NamingException ne){
			System.out.println("ne : " + ne);
		}
	}
	int getTotal(){
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		int total = 0;
		try{
			con = ds.getConnection();
			stmt = con.createStatement();
			rs = stmt.executeQuery(QgetSQL.QG_TOTAL);
			if(rs.next()){
				total = rs.getInt(1);
			}
		}catch(SQLException se){
			System.out.println("se : " + se);
			return -1;
		}finally{
			try{
				if(rs != null)rs.close();
				if(stmt != null) stmt.close();
				if(con != null) con.close();
			}catch(SQLException se){
			}
		}
		return total;
	}
	ArrayList<QgetDTO> list(int pg){
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ArrayList<QgetDTO> list = new ArrayList<QgetDTO>();
		try{
			con = ds.getConnection();
			pstmt = con.prepareStatement(QgetSQL.QG_LIST);
			int min = (pg-1)*10;
			pstmt.setInt(1, min);
			rs = pstmt.executeQuery();
			while(rs.next()){
				int num = rs.getInt(1);
				String id = rs.getString(2);
				String nick = rs.getString(3);
				String content = rs.getString(4);
				int good = rs.getInt(5);
				int bad = rs.getInt(6);
				String ctime = rs.getString(7);
				list.add(new QgetDTO(ctime, num, id, content, good, bad, null, nick));
			}
			return list;
		}catch(SQLException se){
			System.out.println("se : " + se);
			return null;
		}finally{
			try{
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			}catch(SQLException se){
			}
		}
	}
	ArrayList<QgetDTO> bestList(){
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		ArrayList<QgetDTO> bestlist = new ArrayList<QgetDTO>();
		try{
			con = ds.getConnection();
			stmt = con.createStatement();
			rs = stmt.executeQuery(QgetSQL.QG_BEST);
			while(rs.next()){
				int num = rs.getInt(1);
				String id = rs.getString(2);
				String nick = rs.getString(3);
				String content = rs.getString(4);
				int good = rs.getInt(5);
				int bad = rs.getInt(6);
				String ctime = rs.getString(7);
				bestlist.add(new QgetDTO(ctime, num, id, content, good, bad, null, nick));
			}
		}catch(SQLException se){
			System.out.println("se : " +se);
		}finally{
			try{
				if(rs != null) rs.close();
				if(stmt != null) stmt.close();
				if(con != null) con.close();
			}catch(SQLException se){
			}
		}
		return bestlist;
	}
	int insert(QgetDTO dto){
		Connection con = null;
		PreparedStatement pstmt = null;
		try{
			con = ds.getConnection();
			pstmt = con.prepareStatement(QgetSQL.QG_INSERT);
			pstmt.setString(1, dto.getId());
			pstmt.setString(2, dto.getContent());
			int i = pstmt.executeUpdate();
			if(i == 1) return 1;
			else return 0;
		}catch(SQLException se){
			return -1;
		}finally{
			try{
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			}catch(SQLException se){}
		}
	}
	int delete(int num){
		Connection con = null;
		PreparedStatement pstmt = null;
		try{
			con = ds.getConnection();
			pstmt = con.prepareStatement(QgetSQL.QG_DELETE);
			pstmt.setInt(1, num);
			int i = pstmt.executeUpdate();
			return i;
		}catch(SQLException se){
			return -1;
		}finally{
			try{
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			}catch(SQLException se){}
		}
	}
	
	//good bad history check
	String qgcheck(int qnum, String userid){
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String check = "";
		try{
			con = ds.getConnection();
			pstmt = con.prepareStatement(QgetSQL.QG_GB_CHECK);
			pstmt.setInt(1, qnum);
			pstmt.setString(2, userid);
			rs = pstmt.executeQuery();
			while(rs.next()){  //���ƿ� �Ⱦ�� ����������
				check = rs.getString(1);
			}
			if(check == null || check.equals("")){ //���� ���ų� �����ΰ��=>���ƿ� �Ⱦ�� ���� ���°��
				return "3";
			}else{
				check = check.trim();
				return check; //���ƿ� ����� ���� ������ ��� ��ȯ
			}
		}catch(SQLException se){
			return "-1";
		}finally{
			try{
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			}catch(SQLException se){}
		}
	}
	
	//good bad update  num->������ȣ, what->"1"(like),"2"(hate), userid
	void updateGD(int num, String what, String userid){
		Connection con = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstmt2 = null;
		try{
			con = ds.getConnection();
			con.setAutoCommit(false); 
			if(what.equals("1")){//���ƿ��ϰ��
				pstmt = con.prepareStatement(QgetSQL.QG_GOOD_UP);
			}else{
				pstmt = con.prepareStatement(QgetSQL.QG_DOWN_UP);				
			}
			pstmt.setInt(1, num);
			pstmt2 = con.prepareStatement(QgetSQL.QG_GB_INSERT);
			pstmt2.setInt(1, num);
			pstmt2.setString(2, what);
			pstmt2.setString(3, userid);
			int i = pstmt.executeUpdate(); //���� ���̺��� ���ƿ� ������Ʈ
			int j = pstmt2.executeUpdate();
			
			con.commit();
		}catch(SQLException se){
			System.out.println("se : " + se);
			if(con!=null){
				try{
					con.rollback();
				}catch(SQLException se2){
				}
			}
		}finally{
			try{
				con.setAutoCommit(true); 
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			}catch(SQLException se){}
		}
	}
	
	//���ƿ� �Ǿ�� ���� ���̺�
	/*
	int insertGB(int num, String what, String userid){
		Connection con = null;
		PreparedStatement pstmt = null;
		try{
			con = ds.getConnection();
			pstmt = con.prepareStatement(QgetSQL.QG_GB_INSERT);
			pstmt.setInt(1, num);
			pstmt.setString(2, what);
			pstmt.setString(3, userid);
			int i = pstmt.executeUpdate();
			return i;  //�����ϸ� 1����
		}catch(SQLException se){
			return -1; //�����ϸ� -1����
		}finally{
			try{
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			}catch(SQLException se){}
		}
	}
	*/
}
